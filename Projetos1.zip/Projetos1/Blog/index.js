import express from 'express';
import bodyParser from "body-parser";

const app = express();
const port = 3000;

let blogPosts = [];

app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: true }));

app.set('view engine', 'ejs');

app.get("/", (req, res) => {
    res.render("index.ejs",{
        blogText:'',
        blogPosts:blogPosts
    });
})

app.post("/submit", (req, res) => {
    const newPost = {
        id: blogPosts.length,
        message: req.body.message,
    }
    blogPosts.push(newPost);
    res.render("index.ejs", {
        blogPosts: blogPosts
    });
})


app.post("/edit/:id", (req, res) => {
    const id = req.params.id;
    blogPosts[id].message = req.body.updatedMessage;
    res.redirect("/");
})


app.post("/delete/:id", (req, res) => {
    const postId = parseInt(req.params.id);
    blogPosts = blogPosts.filter(post => post.id !== postId);
    res.redirect("/");
})

app.listen(port, () => {
    console.log(`Server started on port ${port}`);
})
