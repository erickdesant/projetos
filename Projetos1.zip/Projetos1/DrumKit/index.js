let  buttonsQuery  = document.querySelectorAll("button");

instruments = {
    w : new Audio('sounds/crash.mp3'),
    a : new Audio('sounds/kick-bass.mp3'),
    s : new Audio('sounds/snare.mp3'),
    d : new Audio('sounds/tom-1.mp3'),
    j : new Audio('sounds/tom-2.mp3'),
    k : new Audio('sounds/tom-3.mp3'),
    l : new Audio('sounds/tom-4.mp3'),
}

for (let i = 0; i < buttonsQuery.length; i++) {
    buttonsQuery[i].addEventListener("click", function (){
        this.style.color = 'red';
        animation(e.key);
        instruments[this.innerHTML].play();
    });
}

document.addEventListener("keypress", function(e) {
    switch (e.key){
        case 'w':
            animation(e.key);
            instruments.w.play();
            break;
        case 'a':
            animation(e.key);
            instruments.a.play();
            break;
        case 's':
            animation(e.key);
            instruments.s.play();
            break;
        case 'd':
            animation(e.key);
            instruments.d.play();
            break;
        case 'j':
            animation(e.key);
            instruments.j.play();
            break;
        case 'k':
            animation(e.key);
            instruments.k.play();
            break;
        case 'l':
            animation(e.key);
            instruments.l.play();
            break;
    }
})

function animation(currentKey){
    let activeButton = document.querySelector("." + currentKey);
    activeButton.classList.add("pressed");
    setTimeout(function(){
        activeButton.classList.remove("pressed");
    },100);
}