let buttonColor = ["red", "blue", "green","yellow"];
let gamePattern = [];
let userChosenColor;
let userClickedPattern = [];
let gameStartCounter = 0;
let level = 0;
let currentLevel = 0;

$(document).on("keypress", function (event) {
    if (event.key === 'a' && gameStartCounter === 0) {
        nextSequence();
        $("h1").text("Level " + level);
        gameStartCounter++;
    }
})

function startOver(){
    level = 0;
    gamePattern = [];
    userClickedPattern = [];
    gameStartCounter = 0;
    $("h1").text("Press A key to Start");
}

function nextSequence(){
    let randomNumber =  Math.floor(Math.random() * 4) ;
    let randomChosenColor = buttonColor[randomNumber];
    setTimeout(function (){
        playSound(randomChosenColor);
        animatePress(randomChosenColor);
        $("#" + randomChosenColor).fadeOut(100).fadeIn(100);
    },1000)
    gamePattern.push(randomChosenColor);
    level++;
    $("h1").text("Level " + level);
    console.log(gamePattern);
}


function checkAnswer(currentLevel){
    for (let i = 0; i < currentLevel; i++) {
        if(gamePattern[i] !== userClickedPattern[i]){
            console.log("fail");
            let failAudio = new Audio("sounds/wrong.mp3");
            failAudio.play();
            $("body").addClass("game-over");
            setTimeout(function(){
                $("body").removeClass("game-over");
            },200)
            $("h1").text("Game over,press any key to restart");
            $(document).off("keypress").on("keypress", function(event){
                startOver();
                if (event.key === 'a' && gameStartCounter === 0) {
                    nextSequence();
                    $("h1").text("Level " + level);
                    gameStartCounter++;
                }
            });
            console.log(gameStartCounter);
            return false;
        }
    }
    console.log("success");
    return true;
}


$(".btn").on("click",function(e){
    currentLevel++;
    switch(e.target.id){
        case "red":
            userChosenColor = "red";
            playSound(userChosenColor);
            animatePress(userChosenColor);
            userClickedPattern.push(userChosenColor);
            if(userClickedPattern.length === gamePattern.length){
                if(checkAnswer(currentLevel) === true){
                    nextSequence();
                    userClickedPattern = [];
                }
            }
            break;
        case "blue":
            userChosenColor = "blue";
            playSound(userChosenColor);
            animatePress(userChosenColor);
            userClickedPattern.push(userChosenColor);
            if(userClickedPattern.length === gamePattern.length){
                if(checkAnswer(currentLevel) === true){
                    nextSequence();
                    userClickedPattern = [];
                }
            }
            break;
        case "green":
            userChosenColor = "green";
            playSound(userChosenColor);
            animatePress(userChosenColor);
            userClickedPattern.push(userChosenColor);
            if(userClickedPattern.length === gamePattern.length){
                if(checkAnswer(currentLevel) === true){
                    nextSequence();
                    userClickedPattern = [];
                }
            }
            break;
        case "yellow":
            userChosenColor = "yellow";
            playSound(userChosenColor);
            animatePress(userChosenColor);
            userClickedPattern.push(userChosenColor);
            if(userClickedPattern.length === gamePattern.length){
                if(checkAnswer(currentLevel) === true){
                    nextSequence();
                    userClickedPattern = [];
                }
            }
            break;
    }
    console.log(userClickedPattern);
})

function playSound(name){
    let audio = new Audio("sounds/" + name + ".mp3");
    audio.play();
}

function animatePress(currentColor){
    $("#" + currentColor).addClass("pressed");
    setTimeout(function(){
        $("#" + currentColor).removeClass("pressed");
    },100);
}
