function rollDice(){
    let dice1 = Math.floor(Math.random() * 6) + 1;
    let dice2 = Math.floor(Math.random() * 6) + 1;

    let idCard1 = "dice1";
    let idCard2 = "dice2";

    chooseCard(dice1,idCard1);
    chooseCard(dice2,idCard2);

    if(dice1 > dice2){
        document.querySelector('h1').innerText = "Yugi venceu!";
        document.querySelector(".reaction #reactionyugi").src = "assets/yugiwin.jpg";
        document.querySelector(".reaction #reactionkaiba").src = "assets/kaibalose.jpg";
    }else if (dice2 > dice1){
        document.querySelector('h1').innerText = "Kaiba venceu!";
        document.querySelector(".reaction #reactionyugi").src = "assets/yugilose.jpg";
        document.querySelector(".reaction #reactionkaiba").src = "assets/kaibawin.jpg";
    }else{
        document.querySelector('h1').innerText = "Empate! Jogue novamente.";
        document.querySelector(".reaction #reactionyugi").src = "assets/yugistart.jpg";
        document.querySelector(".reaction #reactionkaiba").src = "assets/kaibastart.jpg";
    }
}

function chooseCard(dice,idCard){
    switch(dice) {
        case 1 :
            document.getElementById(idCard).src = "assets/kuriboh.jpg";
            break;
        case 2 :
            document.getElementById(idCard).src = "assets/flameswordsman.jpg"
            break;
        case 3 :
            document.getElementById(idCard).src = "assets/gaiaknight.jpg"
            break;
        case 4 :
            document.getElementById(idCard).src = "assets/redeyes.jpg"
            break;
        case 5 :
            document.getElementById(idCard).src = "assets/darkmagician.jpg"
            break;
        case 6 :
            document.getElementById(idCard).src = "assets/blueeyes.jpg"
            break;
    }
}